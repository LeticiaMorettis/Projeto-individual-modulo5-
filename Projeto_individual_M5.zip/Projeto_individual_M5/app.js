//http://www.npmjs.com/package/chalk?activeTab=readme
//https://www.npmjs.com/package/readline-sync
//https://expressjs.com/pt-br/starter/installing.html
import chalk from 'chalk'
import readlineSync from "readline-sync"
import express from "express"

const propriedade = [];
let input = "";

console.log("Digite as propriedades css. Digite 'SAIR' para finalizar.");

while (input.toLowerCase() !== "sair") {
input = readlineSync.question("Digite uma propriedade; ");
if (input.toLowerCase() !== "sair") {
propriedade.push(input);
}
}

console.log("Lista ordenada de propriedades CSS:")
console.log(chalk.blue.underline(propriedade.sort().join("\n")));